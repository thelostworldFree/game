function PositionConfig(){
}
//帽子
PositionConfig.Head = 0;
//手
PositionConfig.Hand = 1;
//身
PositionConfig.Body = 2;
//脚
PositionConfig.Foot = 3;
//饰品
PositionConfig.Accessories = 4;

PositionConfig.positions = [PositionConfig.Head,PositionConfig.Hand,PositionConfig.Body,PositionConfig.Foot,PositionConfig.Accessories];
