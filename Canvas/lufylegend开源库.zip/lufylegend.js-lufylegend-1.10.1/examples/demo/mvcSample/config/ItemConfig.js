function ItemType(){
}
//英雄召唤石
ItemType.CHARACTER_STONE = "character_stone";
//英雄碎片
ItemType.CHARACTER_FRAGMENT = "character_fragment";
//装备碎片
ItemType.ARTIFACT_FRAGMENT = "artifact_fragment";
//装备
ItemType.ARTIFACT = "artifact";
//经验果
ItemType.EXP = "exp";