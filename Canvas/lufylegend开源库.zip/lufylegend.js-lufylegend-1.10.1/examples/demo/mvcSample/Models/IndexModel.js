function IndexModel(){
	base(this,MyModel,[]);
}
IndexModel.prototype.construct=function(){
};
